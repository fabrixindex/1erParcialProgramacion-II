package sistemagestionrecateanimal;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * Centro de rescate que registra los animales
 */
public class CentroDeRescate {
    private final String nombre;
    private final List<Animal> animales;

    public CentroDeRescate(String nombre) {
        this.nombre = nombre;
        this.animales = new ArrayList<>();
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void agregarAnimal(Animal animal) throws AnimalDuplicadoException {
        Objects.requireNonNull(animal, "El animal no puede ser nulo");
        if (animales.contains(animal)) {
            throw new AnimalDuplicadoException(animal.getCodigo(), animal.getNombre());
        }
        animales.add(animal);
    }
    
    public List<Animal> filtrarPorEstado(EstadoSalud estado) {
        Objects.requireNonNull(estado, "El estado no puede ser nulo");
        List<Animal> resultado = new ArrayList<>();
        
        for(Animal a: animales) {
            if(a.getEstadoSalud() == estado) {
                resultado.add(a);
            }
        }
        return resultado;
    }
    
    public List<Animal> obtenerAnimalesConCostoMaximo(double maximo) {
        if(maximo <= 0 ){
            throw new IllegalArgumentException("El costo maximo debe ser mayor a 0");
        
        }
        
        List<Animal> resultado = new ArrayList<>();
        
        for(Animal a: animales) {
            if(a.calcularCostoDiario() <= maximo) {
                resultado.add(a);
            }
        }
        return resultado;
    }

    public List<Animal> obtenerAnimales() {
        return new ArrayList<>(animales);
    }
    
    
}
