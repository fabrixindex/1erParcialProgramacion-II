package sistemagestionrecateanimal;

/**
 *
 * Mamifero: extiende de animal y puede rehabilitarse
 */
public class Mamifero extends Animal implements Rehabilitable {

    private static final double FACTOR_COSTO = 10;
    
    private final double peso;
    
    public Mamifero(String codigo, String nombre, EstadoSalud estadoSalud, double peso) {
        super(codigo, nombre, estadoSalud);
        this.peso = validarPositivo(peso, "El peso ");
    }
    

    @Override
    public double calcularCostoDiario() {
        return peso * FACTOR_COSTO;
    }

    @Override
    public String rehabilitar() {
        return "Rehabilitando al mamifero " + getNombre() + " " + getCodigo();
    }
    
    
}
