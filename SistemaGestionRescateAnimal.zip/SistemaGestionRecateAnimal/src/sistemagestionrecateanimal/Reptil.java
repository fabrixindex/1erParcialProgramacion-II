package sistemagestionrecateanimal;

/**
 *
 * Reptil: extiende de animal 
 */
public class Reptil extends Animal implements Liberable {
    
    private static final double COSTO_BASE = 15;
    
    private final double longitud; 

    public Reptil(String codigo, String nombre, EstadoSalud estadoSalud, double longitud) {
        super(codigo, nombre, estadoSalud);
        this.longitud = validarPositivo(longitud, "La longitud ");
    }

    public double getLongitud() {
        return longitud;
    }

    @Override
    public double calcularCostoDiario() {
        return longitud + COSTO_BASE;
    }

    @Override
    public String liberar() {
        return "Liberando al reptil " + getNombre() + " " + getCodigo();
    }
    
    
}
