package sistemagestionrecateanimal;

/**
 *
 * Ave: Extiende de animal y puede rehabilitarse y liberarse
 */
public class Ave extends Animal implements Rehabilitable, Liberable {
    
    private final double envergaduraAlar; // cm
    private static final double MULTIPLICADOR_COSTO = 2;

    public Ave(String codigo, String nombre, EstadoSalud estadoSalud, double envergaduraAlar) {
        super(codigo, nombre, estadoSalud);
        this.envergaduraAlar = envergaduraAlar;
    }

    public double getEnvergaduraAlar() {
        return envergaduraAlar;
    }
    
    @Override
    public double calcularCostoDiario() {
        return envergaduraAlar * MULTIPLICADOR_COSTO;
    }

    @Override
    public String liberar() {
        return "Liberando al ave " + getNombre() + " " + getCodigo();
    }

    @Override
    public String rehabilitar() {
        return "Rehabilitando al ave " + getNombre() + " " + getCodigo();
    }

    
    
}
