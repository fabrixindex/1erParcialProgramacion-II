package sistemagestionrecateanimal;

public interface Rehabilitable {
    String rehabilitar();
}
