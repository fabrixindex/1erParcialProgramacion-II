package sistemagestionrecateanimal;

/**
 * Estados de salud posibles de un animal.
 */
public enum EstadoSalud {
    CRITICO,
    EN_RECUPERACION,
    ESTABLE
}
