package sistemagestionrecateanimal;


public interface Liberable {
    String liberar();
}
