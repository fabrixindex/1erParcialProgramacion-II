package sistemagestionrecateanimal;

public class AnimalDuplicadoException extends IllegalArgumentException {
    
    public AnimalDuplicadoException(String codigo, String nombre) {
        super("Ya existe un animal con codigo " + codigo + "y nombre " + nombre);
    }
}
