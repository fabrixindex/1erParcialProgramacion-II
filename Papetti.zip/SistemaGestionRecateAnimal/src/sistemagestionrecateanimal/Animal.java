
package sistemagestionrecateanimal;

import java.util.Objects;

/**
 *
 * Animal del centro de rescate. 
 * 
 */
public abstract class Animal {
    
    private final String codigo;
    private final String nombre;
    private final EstadoSalud estadoSalud;

    public Animal(String codigo, String nombre, EstadoSalud estadoSalud) {
        this.codigo = validarTexto(codigo, "El codigo");
        this.nombre = validarTexto(nombre, "El nombre");
        this.estadoSalud = Objects.requireNonNull(estadoSalud, "el estado de salud no puede ser nulo!");
    }
    
    protected static String validarTexto(String valor, String campo) {
        if(valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(campo + " no puede ser nulo ni estar en blanco.");
        }
        return valor;
    }
    
    protected static double validarPositivo(double valor, String campo) {
        if(valor <= 0) {
            throw new IllegalArgumentException(campo + " debe ser si o si positivo.");
        }
        return valor;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public EstadoSalud getEstadoSalud() {
        return estadoSalud;
    }
    
    public abstract double calcularCostoDiario();
    
    @Override
    public boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof Animal)) return false;
        Animal otro = (Animal) o;
        return codigo.equals(otro.codigo) && nombre.equals(otro.nombre);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(codigo, nombre);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + " [" + codigo + "]" + nombre + "-" + estadoSalud;
    }    
    
    
    
    
}
